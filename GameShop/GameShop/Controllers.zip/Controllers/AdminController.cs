﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using GameShop.ApplicationLogic.Services;
using GameShop.ApplicationLogic.Model;
using GameShop.Models.Admins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace GameShop.Controllers
{
    public class AdminController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly AdminServices adminServices;
        public AdminController(UserManager<IdentityUser> userManager, AdminServices adminServices)
        {
            this.userManager = userManager;
            this.adminServices = adminServices;
        }
        public ActionResult Index()
        {
            try
            {
                var userId = userManager.GetUserId(User);
                var admin = adminServices.GetAdminByAdminId(userId);
                var GameList = adminServices.GetGameList();

                return View(new AdminGamesViewModel { Admin = admin, Games = GameList });
            }
            catch (Exception)
            {
                return BadRequest("Invalid request received ");
            }
        }

        [HttpGet]
        public IActionResult AddCourse()
        {
            return View();
        }

        public IActionResult AddGame([FromForm]AdminAddGameViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            var userId = userManager.GetUserId(User);
            adminServices.addGame(userId, model.gameName, model.Price,  model.Description);
            return Redirect(Url.Action("Index", "Admin"));

        }
    }
    
}

